var u='http://www.google.co.jp/translate?langpair=ja%7Cen&hl=ja&ie=UTF8&u=';
u += escape(location.href);
document.write('<a href="'+u+'" target="_blank" class="toEnglish">to English</a> ');
document.write('<a href="http://ryouchi.seesaa.net/article/28672470.html" target="_blank" class="r_logo"><img src="http://ryouchi.up.seesaa.net/icon/r_icon.png" width="16" height="14" border="0"/></a>');
