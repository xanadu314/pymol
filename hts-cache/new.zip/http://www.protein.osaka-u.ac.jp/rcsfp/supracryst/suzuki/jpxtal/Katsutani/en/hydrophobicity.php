<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html lang="en">
<head>
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<meta http-equiv="Content-Type" content="text/html; charset=Shift_JIS">
<meta name="Description" content="">
<meta name="Keywords" content="PyMOL,tutorial,protein,structural biology,x-ray crystallography">
<title>PyMOL tutorial -Hydrophobicity-</title>
<link rel="stylesheet" href="base.css" type="text/css" media="screen,tv">
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-19185307-3', 'osaka-u.ac.jp');
  ga('send', 'pageview');

</script>
</head>
<body>
<div id="wrapper">
<div id="header">

<div Align="right">
<a href="../index.php">Japanese</a>
</div>

<!-- ���o�� -->
<h1>PyMOL tutorial | Hydrophobicity</h1>
<!-- �^�C�g�� -->
<p class="logo"><a href="index.php">PyMOL tutorial</a></p>
<!-- �T�v -->
<p class="description">English version of Japanese website about structural biology</p>
</div>
<!-- / header end -->
<div id="contents">
<!-- �p�������X�g -->
<p class="topic-path"><a href="index.php">Home</a> &gt; PyMOL &gt; Hydrophobicity</p>



<!-- �R���e���c �������� -->
<h2>Download script</h2>
By using the script called "Color h", you can color-code by hydrophobicity.
<ol>
<li>Access <a href="http://pymolwiki.org/index.php/Color_h" target="_blank">PyMOL wiki Color h</a>.</li>
<li>Make a copy of in the gray box under the The code, and then paste it into a text file</li>
<img src="../figure/hydrophobicity2.png" width="500">
<br><br>

<li>Save as "color_h.py"</li>
</ol>

Or download <a href="../color_h.py" target="_blank">color_h.py</a>
<br><br><br>


<h2>Run color_h on PyMOL</h2>
<ol>
<li>File �� Run �� color_h.py</li>
<li>Enter the comman line</li>
<div style="padding: 10px; margin-bottom: 10px; border: 1px dotted #333333;">
color_h
</div>
<li>Show �� Surface</li>
<img src="../figure/hydrophobicity1.png" width="500">
red:Hydrophobic surface


<!--�R���e���c �����܂� -->

</div><!-- / contents end -->

<div id="sidebar">
<!-- �T�C�h�o�[ �������� -->
<p class="sidetitle">PyMOL</p>
<ul class="localnavi">
  <li><a href="install.php">Installation</a></li>
  <li><a href="hydrophobicity.php">Hydrophobicity</a></li>
  <li><a href="potential.php">Electrostatic potential</a></li>
  <li><a href="consurf.php">Conservation</a></li>
  <li><a href="interface.php">Interaction interface</a></li>
  <li><a href="hydrogenbond.php">Hydrogen bond</a></li>
</ul>

<div align="center"><a href="../mail.php"><img src="../figure/mail.png" border="0"></a></div>
<br>


<ul style="list-style:none;">
<li><!-- Twitter -->
<a href="https://twitter.com/share" class="twitter-share-button">Tweet</a>
<script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0],p=/^http:/.test(d.location)?'http':'https';if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src=p+'://platform.twitter.com/widgets.js';fjs.parentNode.insertBefore(js,fjs);}}(document, 'script', 'twitter-wjs');</script>
</li>

<li><!-- facebook ������ -->
<iframe src="//www.facebook.com/plugins/like.php?href=http%3A%2F%2Fwww.protein.osaka-u.ac.jp%2Frcsfp%2Fsupracryst%2Fsuzuki%2Fjpxtal%2FKatsutani%2F&amp;width&amp;layout=button_count&amp;action=like&amp;show_faces=false&amp;share=false&amp;height=21" scrolling="no" frameborder="0" style="border:none; overflow:hidden; height:21px;" allowTransparency="true"></iframe>
</li>

<li><!-- Google +1 -->
<div class="g-plusone" data-size="medium" data-annotation="inline" data-width="300"></div>

<script type="text/javascript">
  window.___gcfg = {lang: 'ja'};

  (function() {
    var po = document.createElement('script'); po.type = 'text/javascript'; po.async = true;
    po.src = 'https://apis.google.com/js/platform.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(po, s);
  })();
</script>
</li>

<li><!-- �͂Ăȃu�b�N�}�[�N -->
<a href="http://b.hatena.ne.jp/entry/http://www.protein.osaka-u.ac.jp/rcsfp/supracryst/suzuki/jpxtal/Katsutani/" class="hatena-bookmark-button" data-hatena-bookmark-title="Windows�ōs����" data-hatena-bookmark-layout="standard-balloon" data-hatena-bookmark-lang="ja" title="���̃G���g���[���͂Ăȃu�b�N�}�[�N�ɒǉ�"><img src="http://b.st-hatena.com/images/entry-button/button-only@2x.png" alt="���̃G���g���[���͂Ăȃu�b�N�}�[�N�ɒǉ�" width="20" height="20" style="border: none;" /></a><script type="text/javascript" src="http://b.st-hatena.com/js/bookmark_button.js" charset="utf-8" async="async"></script>
</li>
</ul><!-- �T�C�h�o�[ �����܂� -->
</div><!-- / sidebar end -->
<div id="footer">
<div align="right">
<a href="#header"><img src="../figure/page_top.gif"></a>
</div><br>

<div Align="center">
| <a href="index.php">Home</a> | <a href="../index.php" target="_blank">Japanese</a> |
</div>

<p id="page-top"><a href="#header">PAGE TOP</a></p>
</div><!-- / footer end -->
</div><!-- / wrapper end -->
</body>
</html>